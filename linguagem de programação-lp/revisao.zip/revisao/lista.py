#Criando lista:
frutas = ["maça", "banana", "mamão"]

#Acessando:
print(frutas[0]) #maça

#Adicionando
frutas.append("uva")

#Removendo
frutas.remove("banana")

#Alterando
frutas[1] = "abacaxi"