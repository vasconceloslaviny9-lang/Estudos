aluno = {
    "nome": "Laviny",
    "idade" : 18,
    "nota": 9.0
}
print(aluno["nome"])


#Alterando valores:
aluno["nota"] = 9.5



#Adicionando nova chave:
aluno["turma"] = "3A"
