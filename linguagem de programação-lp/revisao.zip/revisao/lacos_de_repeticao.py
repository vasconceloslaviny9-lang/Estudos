#for
for i in range(5):
    print("Olá", i)




frutas = ["maça", "banana", "uva"]
for frutas in frutas:
    print(frutas)

#while
contador = 1 
while contador <= 5:
    print(contador)
    contador += 1
