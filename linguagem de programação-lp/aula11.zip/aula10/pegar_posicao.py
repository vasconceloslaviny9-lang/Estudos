import pyautogui
import time


time.sleep(10)
print(pyautogui.position())