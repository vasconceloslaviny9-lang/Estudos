import pyautogui
import time

time.sleep(3)
pyautogui.click(x=1111, y=1053)
