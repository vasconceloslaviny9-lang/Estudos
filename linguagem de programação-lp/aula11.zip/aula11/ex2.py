import pyautogui
import time

pyautogui.move(47, 243, duration=1)
pyautogui.move(210, 236, duration=1)
pyautogui.move(262, 365, duration=1)


