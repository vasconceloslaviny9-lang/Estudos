def saudacao(nome="Visitante"):
    print(f"Bem-vindo(a), {nome}!")

saudacao()

saudacao("Laviny")