n1 = int(input("Digite o primeiro número inteiro: "))
n2 = int(input("Digite o segundo número inteiro: "))

if n1 > n2:
    print("O maior é:", n1)
elif n2 > n1:
    print("O maior é:", n2)
else:
    print("Os números são iguais.")